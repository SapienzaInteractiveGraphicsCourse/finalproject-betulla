goog.require('Zlib.Unzip');

goog.exportSymbol('Zlib.Unzip', Zlib.Unzip);
goog.exportSymbol(
  'Zlib.Unzip.prototype.decompress',
  Zlib.Unzip.prototype.decompress
);
goog.exportSymbol(
  'Zlib.Unzip.prototype.getFilenames',
  Zlib.Unzip.prototype.getFilenames
);
goog.exportSymbol(
  'Zlib.Unzip.prototype.setPassword',
  Zlib.Unzip.prototype.setPassword
);