goog.require('Zlib.GunzipMember');

goog.exportSymbol('Zlib.GunzipMember', Zlib.GunzipMember);
goog.exportSymbol(
  'Zlib.GunzipMember.prototype.getName',
  Zlib.GunzipMember.prototype.getName
);
goog.exportSymbol(
  'Zlib.GunzipMember.prototype.getData',
  Zlib.GunzipMember.prototype.getData
);
goog.exportSymbol(
  'Zlib.GunzipMember.prototype.getMtime',
  Zlib.GunzipMember.prototype.getMtime
);