ZlibOriginal = Zlib;
Zlib = void 0;